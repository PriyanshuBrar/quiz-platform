import { supabase } from "./supabase.js";

console.log("addQuestions.js loaded");


const { data: { session } } = await supabase.auth.getSession();
if (!session) {
  window.location.href = "login.html";
}

const params = new URLSearchParams(window.location.search);
const quizId = params.get("quiz");
const quizCode = params.get("code");


async function maybeShowCode() {
  const display = document.getElementById("quizCodeDisplay");
  if (!display) return;

  const { data, error } = await supabase
    .from('quizzes')
    .select('status')
    .eq('id', quizId)
    .single();

  if (error) {
    console.error('Unable to fetch quiz status', error);
    return;
  }

  if (data?.status === 'published' && quizCode) {
    display.innerText = `Share this quiz code with players: ${quizCode}`;
  }
}

maybeShowCode();

const msg = document.getElementById("msg") || document.createElement("p");
const publishMsg = document.getElementById("publishMsg") || document.createElement("p");
const countEl = document.getElementById("totalCount") || document.createElement("span");

// SAFETY CHECK
if (!quizId) { 
  msg.innerText = "Invalid quiz link";
  throw new Error("quizId missing");
}

// redirect if quiz already published and ensure creator ownership
(async () => {
  const { data: quiz, error } = await supabase
    .from('quizzes')
    .select('status,code,creator_id')
    .eq('id', quizId)
    .single();

  if (error) {
    console.error('Unable to fetch quiz', error);
    msg.innerText = 'Unable to load quiz';
    return;
  }

  // guard: only creator may view this page
  const { data: { user } } = await supabase.auth.getUser();
  if (!user || quiz.creator_id !== user.id) {
    alert('You are not authorized to manage this quiz');
    window.location.href = 'index.html';
    return;
  }

  if (quiz?.status === 'published') {
    window.location.href = `publish-success.html?code=${encodeURIComponent(quiz.code || '')}`;
  }
})();

// LOAD QUESTION COUNT
async function loadCount() {
  const { count, error } = await supabase
    .from("questions")
    .select("*", { count: "exact", head: true })
    .eq("quiz_id", quizId);

  if (!error) {
    countEl.innerText = count;
  }
}

// we no longer render the question list on this page; questions are
// shown on a separate "view quiz" page so creator can scroll comfortably.
// keep loadCount for display purposes
loadCount();

// ADD QUESTION
const addBtn = document.getElementById("addBtn");
if (addBtn) {
  addBtn.addEventListener("click", async () => {
    const question = document.getElementById("question").value.trim();
    const a = document.getElementById("a").value.trim();
    const b = document.getElementById("b").value.trim();
    const c = document.getElementById("c").value.trim();
    const d = document.getElementById("d").value.trim();
    const correct = document.getElementById("correct").value;

    if (!question || !a || !b || !c || !d) {
      msg.innerText = "Fill all fields";
      return;
    }

    const { error } = await supabase.from("questions").insert({
      quiz_id: quizId,
      question: question,
      option_a: a,
      option_b: b,
      option_c: c,
      option_d: d,
      correct_option: correct
    });

    if (error) {
      msg.innerText = error.message;
      return;
    }

    msg.innerText = "Question added";
    setTimeout(() => { msg.innerText = ""; }, 2000);

    // CLEAR INPUTS
    document.getElementById("question").value = "";
    document.getElementById("a").value = "";
    document.getElementById("b").value = "";
    document.getElementById("c").value = "";
    document.getElementById("d").value = "";

    loadCount();
  });
}

// PUBLISH QUIZ
// note: button id changed to publishQuizBtn in HTML
const publishBtnEl = document.getElementById("publishQuizBtn");
if (publishBtnEl) {
  publishBtnEl.addEventListener("click", async () => {
    const { count } = await supabase
      .from("questions")
      .select("*", { count: "exact", head: true })
      .eq("quiz_id", quizId);

    if (count === 0) {
      publishMsg.innerText = "Add at least one question before publishing";
      return;
    }

    const { error } = await supabase
      .from("quizzes")
      .update({ status: "published" })
      .eq("id", quizId);

    if (error) {
      publishMsg.innerText = error.message;
    } else {
      // redirect to confirmation page with code
      const redirectUrl = `publish-success.html?code=${encodeURIComponent(quizCode || '')}`;
      window.location.href = redirectUrl;
    }
  });
}

// BACK BUTTON (RELIABLE)
const backBtnEl = document.getElementById("backBtn");
if (backBtnEl) {
  backBtnEl.addEventListener("click", () => {
    window.location.href = "index.html";
  });
}
