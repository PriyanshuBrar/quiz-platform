import {
  addParticipantToQuiz,
  clearCurrentRoom,
  findQuizById,
  findQuizByRoomCode,
  formatStatus,
  getCurrentRoom,
  getHighestScore,
  getLeaderboard,
  getSession,
  initializeAppData,
  scoreQuiz,
  setCurrentRoom,
  submitAttempt
} from "./data.js";

initializeAppData();

const page = document.body.dataset.page;
const session = getSession();

if (!session) {
  window.location.href = "./login.html";
}

if (page === "join") setupJoinPage();
if (page === "quiz") setupQuizPage();
if (page === "result") setupResultPage();

function setupJoinPage() {
  const joinForm = document.getElementById("joinForm");
  const roomCodeInput = document.getElementById("roomCodeInput");
  const joinMessage = document.getElementById("joinMessage");
  const waitingCard = document.getElementById("waitingCard");
  const leaveRoomBtn = document.getElementById("leaveRoomBtn");
  let waitingInterval = null;

  restoreWaitingState();

  joinForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const roomCode = roomCodeInput.value.trim();
    const quiz = findQuizByRoomCode(roomCode);

    if (!quiz) {
      joinMessage.textContent = "No room found for that code.";
      return;
    }

    addParticipantToQuiz(quiz.id, { userId: session.id, name: session.name || "Guest Participant" });
    setCurrentRoom({ quizId: quiz.id, roomCode: quiz.host.roomCode, participantId: session.id });
    joinMessage.textContent = `Joined room ${quiz.host.roomCode}.`;
    renderWaitingRoom(quiz);
  });

  leaveRoomBtn?.addEventListener("click", () => {
    clearCurrentRoom();
    waitingCard.classList.add("hidden-block");
    joinMessage.textContent = "You left the room.";
    if (waitingInterval) clearInterval(waitingInterval);
  });

  function restoreWaitingState() {
    const room = getCurrentRoom();
    if (!room) return;
    const quiz = findQuizById(room.quizId);
    if (!quiz) return;
    renderWaitingRoom(quiz);
  }

  function renderWaitingRoom(quiz) {
    waitingCard.classList.remove("hidden-block");
    document.getElementById("waitingQuizTitle").textContent = quiz.title;
    document.getElementById("waitingDescription").textContent = quiz.description;
    document.getElementById("waitingParticipantName").textContent = session.name || "Guest Participant";
    document.getElementById("waitingStatusBadge").textContent = `Status: ${formatStatus(quiz.host.status)}`;

    if (waitingInterval) clearInterval(waitingInterval);
    waitingInterval = window.setInterval(() => {
      const freshQuiz = findQuizById(quiz.id);
      if (!freshQuiz) return;
      document.getElementById("waitingStatusBadge").textContent = `Status: ${formatStatus(freshQuiz.host.status)}`;
      if (freshQuiz.host.status === "live") {
        clearInterval(waitingInterval);
        window.location.href = "./quiz.html";
      }
    }, 1000);
  }
}

function setupQuizPage() {
  const room = getCurrentRoom();
  const quiz = room ? findQuizById(room.quizId) : null;
  const message = document.getElementById("quizMessage");

  if (!quiz || quiz.host.status !== "live") {
    message.textContent = "This quiz is not live right now. Join a valid active room first.";
    document.getElementById("nextQuestionBtn").disabled = true;
    return;
  }

  const roomCodeBadge = document.getElementById("quizRoomCodeBadge");
  const questionTitle = document.getElementById("quizQuestionTitle");
  const quizProgress = document.getElementById("quizProgress");
  const questionTypeBadge = document.getElementById("questionTypeBadge");
  const quizMedia = document.getElementById("quizMedia");
  const answerArea = document.getElementById("quizAnswerArea");
  const nextQuestionBtn = document.getElementById("nextQuestionBtn");
  const timerBadge = document.getElementById("timerBadge");

  let currentIndex = 0;
  let timerRef = null;
  const answers = {};
  const startedAt = Date.now();

  roomCodeBadge.textContent = `Room ${quiz.host.roomCode}`;
  renderQuestion();

  nextQuestionBtn.addEventListener("click", () => {
    captureCurrentAnswer();
    goNext();
  });

  function renderQuestion() {
    const question = quiz.questions[currentIndex];
    if (!question) return finalizeQuiz();

    quizProgress.textContent = `Question ${currentIndex + 1} of ${quiz.questions.length}`;
    questionTitle.textContent = question.prompt;
    questionTypeBadge.textContent = question.type.toUpperCase();
    answerArea.innerHTML = "";
    quizMedia.innerHTML = "";
    quizMedia.classList.add("hidden-block");
    message.textContent = "";

    if (question.type === "image" && question.image) {
      quizMedia.innerHTML = `<img src="${question.image}" alt="Question visual">`;
      quizMedia.classList.remove("hidden-block");
    }

    if (question.type === "subjective") {
      answerArea.innerHTML = `
        <label>
          <span>Your response</span>
          <textarea id="subjectiveAnswer" rows="5" placeholder="Type your answer here"></textarea>
        </label>
      `;
    } else {
      const optionsWrapper = document.createElement("div");
      optionsWrapper.className = "answer-area";
      question.options.forEach((option) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "option-button";
        button.textContent = option;
        button.addEventListener("click", () => {
          optionsWrapper.querySelectorAll(".option-button").forEach((entry) => entry.classList.remove("selected"));
          button.classList.add("selected");
        });
        optionsWrapper.appendChild(button);
      });
      answerArea.appendChild(optionsWrapper);
    }

    startTimer(question.timer || 20);
  }

  function startTimer(seconds) {
    clearInterval(timerRef);
    let timeLeft = seconds;
    timerBadge.textContent = `${timeLeft}s`;

    timerRef = setInterval(() => {
      timeLeft -= 1;
      timerBadge.textContent = `${Math.max(timeLeft, 0)}s`;
      if (timeLeft <= 0) {
        clearInterval(timerRef);
        captureCurrentAnswer();
        goNext();
      }
    }, 1000);
  }

  function captureCurrentAnswer() {
    const question = quiz.questions[currentIndex];
    if (!question) return;

    if (question.type === "subjective") {
      answers[question.id] = document.getElementById("subjectiveAnswer")?.value.trim() || "";
      return;
    }

    const selected = answerArea.querySelector(".option-button.selected");
    answers[question.id] = selected ? selected.textContent : "";
  }

  function goNext() {
    currentIndex += 1;
    if (currentIndex >= quiz.questions.length) return finalizeQuiz();
    renderQuestion();
  }

  function finalizeQuiz() {
    clearInterval(timerRef);
    submitAttempt({
      quizId: quiz.id,
      userId: session.id,
      name: session.name || "Guest Participant",
      answers,
      score: scoreQuiz(quiz, answers),
      totalQuestions: quiz.questions.length,
      totalTime: Math.round((Date.now() - startedAt) / 1000)
    });
    window.location.href = "./result.html";
  }
}

function setupResultPage() {
  const room = getCurrentRoom();
  const quiz = room ? findQuizById(room.quizId) : null;
  const gateTitle = document.getElementById("resultGateTitle");
  const gateMessage = document.getElementById("resultGateMessage");
  const resultBoard = document.getElementById("resultBoard");
  const resultLockCard = document.getElementById("resultLockCard");

  if (!quiz) {
    gateTitle.textContent = "No room context found";
    gateMessage.textContent = "Join and attempt a quiz before opening the results page.";
    return;
  }

  const latestQuiz = findQuizById(quiz.id);
  if (!latestQuiz.host.resultsVisible) {
    gateTitle.textContent = "Results are still locked";
    gateMessage.textContent = "The admin has not enabled result visibility yet. Refresh after the host reveals the leaderboard.";
    return;
  }

  const currentAttempt = latestQuiz.attempts.find((attempt) => attempt.userId === session.id);
  const leaderboard = getLeaderboard(latestQuiz.id);

  resultLockCard.classList.add("hidden-block");
  resultBoard.classList.remove("hidden-block");
  document.getElementById("resultQuizTitle").textContent = latestQuiz.title;
  document.getElementById("scoreSummary").innerHTML = `
    <article class="stat-card panel"><strong>${currentAttempt ? currentAttempt.score : 0}</strong><span>Your score</span></article>
    <article class="stat-card panel"><strong>${getHighestScore(latestQuiz.id)}</strong><span>Highest score</span></article>
    <article class="stat-card panel"><strong>${leaderboard.length}</strong><span>Leaderboard entries</span></article>
  `;

  document.getElementById("leaderboardList").innerHTML = leaderboard.length
    ? leaderboard.map((entry, index) => `
      <article class="leaderboard-item top-${index + 1}">
        <div class="leaderboard-rank">${index + 1}</div>
        <div>
          <strong>${entry.name}</strong>
          <p class="muted-copy">${entry.totalTime}s total time</p>
        </div>
        <strong>${entry.score}</strong>
      </article>
    `).join("")
    : `<article class="leaderboard-item"><div>No attempts available yet.</div></article>`;
}
