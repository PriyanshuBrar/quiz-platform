import { getSession, initializeAppData, setSession } from "./data.js";

initializeAppData();

if (document.body.dataset.page === "home") {
  const guestAccessBtn = document.getElementById("guestAccessBtn");
  const session = getSession();

  if (session && session.role === "user") {
    guestAccessBtn.textContent = "Join a Room";
  }

  guestAccessBtn?.addEventListener("click", () => {
    if (!getSession()) {
      setSession({
        id: `guest_${Date.now()}`,
        name: "Guest Participant",
        email: "",
        role: "user",
        isGuest: true
      });
      localStorage.setItem("userRole", "user");
      localStorage.setItem("userEmail", "");
    }
    window.location.href = "./join.html";
  });
}
