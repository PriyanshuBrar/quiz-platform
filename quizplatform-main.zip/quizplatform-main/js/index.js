import { supabase } from "./supabase.js";


document.addEventListener("DOMContentLoaded", async () => {

    try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) {
            console.log("no session, redirecting to login");
            window.location.href = "login.html";
            return;
        }
    } catch (err) {
        console.error("failed to get session", err);
        
    }

    
    const createBtn = document.getElementById("createBtn");
    const joinBtn = document.getElementById("joinBtn");

    if (createBtn) {
        createBtn.addEventListener("click", () => {
            console.log("create button clicked");
            window.location.href = "create-quiz.html";
        });
    }

    if (joinBtn) {
        joinBtn.addEventListener("click", () => {
            window.location.href = "join-quiz.html";
        });
    }
});
