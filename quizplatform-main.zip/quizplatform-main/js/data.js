const STORAGE_KEYS = {
  users: "mm_users",
  session: "mm_session",
  adminRequests: "adminRequests",
  quizzes: "mm_quizzes",
  currentRoom: "mm_current_room"
};

export const SUPER_ADMIN_EMAIL = "9dpravitkoul@gmail.com";

const IMAGE_PLACEHOLDER = "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80";

function uid(prefix = "mm") {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

function nowIso() {
  return new Date().toISOString();
}

function readStore(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (error) {
    console.error(`Failed to read ${key}`, error);
    return fallback;
  }
}

function writeStore(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
  return value;
}

function generateRoomCode() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function seedUsers() {
  return [
    { id: "user_demo", name: "Riya Learner", email: "user@mentimentor.app", password: "user123", role: "user", createdAt: nowIso() },
    { id: "admin_demo", name: "Kabir Host", email: "admin@mentimentor.app", password: "admin123", role: "admin", createdAt: nowIso() },
    { id: "super_demo", name: "Pravit Koul", email: SUPER_ADMIN_EMAIL, password: "super123", role: "superadmin", createdAt: nowIso() }
  ];
}

function seedAdminRequests() {
  return [
    { id: uid("req"), name: "Meera Facilitator", email: "meera@school.edu", reason: "Need to host weekly mentorship quiz sessions.", status: "pending", createdAt: nowIso() },
    { id: uid("req"), name: "Arjun Trainer", email: "arjun@academy.org", reason: "Running internal onboarding assessments every Friday.", status: "approved", createdAt: nowIso() },
    { id: uid("req"), name: "Sneha Workshop Lead", email: "sneha@bootcamp.dev", reason: "Requested admin access without organization context.", status: "rejected", createdAt: nowIso() }
  ];
}

function seedQuizzes() {
  return [
    {
      id: uid("quiz"),
      title: "Frontend Fundamentals Sprint",
      description: "A short live check-in for HTML, CSS, and JavaScript basics.",
      createdBy: "admin_demo",
      createdAt: nowIso(),
      host: { roomCode: "482913", status: "waiting", resultsVisible: false, startedAt: null, endedAt: null },
      participants: [],
      attempts: [],
      questions: [
        { id: uid("q"), type: "mcq", prompt: "Which HTML element is best for the main heading of a page?", options: ["<header>", "<h1>", "<title>", "<section>"], correctAnswer: "<h1>", timer: 20, points: 10, image: "" },
        { id: uid("q"), type: "subjective", prompt: "In one sentence, explain why semantic HTML improves accessibility.", options: [], correctAnswer: "semantic html gives structure and meaning for assistive technologies", timer: 35, points: 10, image: "" },
        { id: uid("q"), type: "image", prompt: "This is an image-based UI prompt. Which CSS property makes an image fill its box without distortion?", options: ["object-fit", "background-size", "image-rendering", "place-content"], correctAnswer: "object-fit", timer: 25, points: 10, image: IMAGE_PLACEHOLDER }
      ]
    }
  ];
}

export function initializeAppData() {
  if (!readStore(STORAGE_KEYS.users)) writeStore(STORAGE_KEYS.users, seedUsers());
  let adminRequests = JSON.parse(localStorage.getItem("adminRequests")) || [];
  if (!adminRequests.length) {
    adminRequests = seedAdminRequests();
    writeStore(STORAGE_KEYS.adminRequests, adminRequests);
  }
  if (!readStore(STORAGE_KEYS.quizzes)) writeStore(STORAGE_KEYS.quizzes, seedQuizzes());
}

export function getUsers() { return readStore(STORAGE_KEYS.users, []); }
export function saveUsers(users) { return writeStore(STORAGE_KEYS.users, users); }
export function getSession() { return readStore(STORAGE_KEYS.session, null); }
export function setSession(session) { return writeStore(STORAGE_KEYS.session, session); }
export function getAdminRequests() { return readStore(STORAGE_KEYS.adminRequests, []); }
export function saveAdminRequests(requests) { return writeStore(STORAGE_KEYS.adminRequests, requests); }
export function getQuizzes() { return readStore(STORAGE_KEYS.quizzes, []); }
export function saveQuizzes(quizzes) { return writeStore(STORAGE_KEYS.quizzes, quizzes); }
export function getCurrentRoom() { return readStore(STORAGE_KEYS.currentRoom, null); }
export function setCurrentRoom(currentRoom) { return writeStore(STORAGE_KEYS.currentRoom, currentRoom); }
export function clearCurrentRoom() { localStorage.removeItem(STORAGE_KEYS.currentRoom); }
export function clearSession() {
  localStorage.removeItem(STORAGE_KEYS.session);
  localStorage.removeItem(STORAGE_KEYS.currentRoom);
  localStorage.removeItem("userRole");
  localStorage.removeItem("userEmail");
}

export function createUser({ name, email, password, role = "user" }) {
  const users = getUsers();
  if (users.some((user) => user.email.toLowerCase() === email.toLowerCase())) return { error: "An account with this email already exists." };
  const newUser = { id: uid("user"), name: name.trim(), email: email.trim().toLowerCase(), password, role, createdAt: nowIso() };
  users.push(newUser);
  saveUsers(users);
  return { user: newUser };
}

export function authenticateUser(email, password) {
  return getUsers().find((entry) => entry.email.toLowerCase() === email.trim().toLowerCase() && entry.password === password) || null;
}

export function createAdminRequest({ name, email, reason }) {
  const requests = getAdminRequests();
  const normalizedEmail = email.trim().toLowerCase();
  const existing = requests.find((request) => request.email === normalizedEmail);
  if (existing) return existing;
  const request = { id: uid("req"), name: name.trim(), email: normalizedEmail, reason: reason.trim(), status: "pending", createdAt: nowIso() };
  requests.unshift(request);
  saveAdminRequests(requests);
  return request;
}

export function getAdminRequestByEmail(email) {
  const normalizedEmail = email.trim().toLowerCase();
  return getAdminRequests().find((request) => request.email === normalizedEmail) || null;
}

export function setAdminRequestStatus(email, status) {
  const normalizedEmail = email.trim().toLowerCase();
  const requests = getAdminRequests();
  const request = requests.find((entry) => entry.email === normalizedEmail);
  if (!request) return null;
  request.status = status;
  saveAdminRequests(requests);
  return request;
}

export function upsertQuiz(quizPayload) {
  const quizzes = getQuizzes();
  const index = quizzes.findIndex((quiz) => quiz.id === quizPayload.id);
  if (index >= 0) quizzes[index] = quizPayload;
  else quizzes.unshift(quizPayload);
  saveQuizzes(quizzes);
  return quizPayload;
}

export function createQuiz({ title, description, questions, createdBy }) {
  return upsertQuiz({
    id: uid("quiz"),
    title: title.trim(),
    description: description.trim(),
    createdBy,
    createdAt: nowIso(),
    host: { roomCode: generateRoomCode(), status: "draft", resultsVisible: false, startedAt: null, endedAt: null },
    participants: [],
    attempts: [],
    questions: questions.map((question) => ({ ...question, id: uid("q"), points: 10 }))
  });
}

export function updateQuiz(quizId, updates) {
  const quizzes = getQuizzes();
  const quiz = quizzes.find((entry) => entry.id === quizId);
  if (!quiz) return null;
  Object.assign(quiz, updates);
  saveQuizzes(quizzes);
  return quiz;
}

export function findQuizByRoomCode(roomCode) { return getQuizzes().find((quiz) => quiz.host.roomCode === roomCode.trim()); }
export function findQuizById(quizId) { return getQuizzes().find((quiz) => quiz.id === quizId); }

export function addParticipantToQuiz(quizId, participant) {
  const quizzes = getQuizzes();
  const quiz = quizzes.find((entry) => entry.id === quizId);
  if (!quiz) return null;
  if (!quiz.participants.find((item) => item.userId === participant.userId)) {
    quiz.participants.push({ ...participant, joinedAt: nowIso() });
    saveQuizzes(quizzes);
  }
  return quiz;
}

export function submitAttempt({ quizId, userId, name, answers, score, totalQuestions, totalTime }) {
  const quizzes = getQuizzes();
  const quiz = quizzes.find((entry) => entry.id === quizId);
  if (!quiz) return null;
  const attemptRecord = { id: uid("attempt"), userId, name, answers, score, totalQuestions, totalTime, submittedAt: nowIso() };
  const existingIndex = quiz.attempts.findIndex((attempt) => attempt.userId === userId);
  if (existingIndex >= 0) quiz.attempts[existingIndex] = attemptRecord;
  else quiz.attempts.push(attemptRecord);
  saveQuizzes(quizzes);
  return attemptRecord;
}

export function scoreQuiz(quiz, answerMap) {
  let score = 0;
  quiz.questions.forEach((question) => {
    const submitted = answerMap[question.id];
    if (!submitted) return;
    if (question.type === "subjective") {
      const normalized = String(submitted).trim().toLowerCase();
      const expected = String(question.correctAnswer).trim().toLowerCase();
      if (normalized && (normalized === expected || normalized.includes(expected) || expected.includes(normalized))) score += question.points;
      return;
    }
    if (String(submitted).trim().toLowerCase() === String(question.correctAnswer).trim().toLowerCase()) score += question.points;
  });
  return score;
}

export function getLeaderboard(quizId) {
  const quiz = findQuizById(quizId);
  if (!quiz) return [];
  return [...quiz.attempts].sort((left, right) => right.score - left.score || left.totalTime - right.totalTime).slice(0, 10);
}

export function getHighestScore(quizId) {
  const leaderboard = getLeaderboard(quizId);
  return leaderboard.length ? leaderboard[0].score : 0;
}

export function formatRole(role) {
  if (role === "superadmin") return "Super Admin";
  if (role === "admin") return "Admin";
  return "User";
}

export function formatStatus(status) {
  return status.charAt(0).toUpperCase() + status.slice(1);
}
