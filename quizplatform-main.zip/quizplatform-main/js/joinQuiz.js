import { supabase } from "./supabase.js";


const { data: { session } } = await supabase.auth.getSession();
if (!session) {
    window.location.href = "login.html";
}


async function fetchQuiz(code, onlyPublished = true) {
    // first try treating input as id (UUID or whatever)
    let q = supabase.from("quizzes").select("*");
    if (onlyPublished) q = q.eq("status", "published");
    q = q.eq("id", code);
    let res = await q.maybeSingle();
    if (res.error) {
        console.warn("error fetching by id", res.error);
    }
    if (res.data) {
        return res;
    }
   
    let q2 = supabase.from("quizzes").select("*");
    if (onlyPublished) q2 = q2.eq("status", "published");
    q2 = q2.eq("code", code);
    res = await q2.maybeSingle();
    if (res.error) {
        console.warn("error fetching by code", res.error);
    }
    return res;
}

function initJoinPage() {
    const joinBtn = document.getElementById("joinQuizBtn");
    const backBtn = document.getElementById("backBtn");
    const quizCodeInput = document.getElementById("quizCodeInput");
    const errorMessage = document.getElementById("errorMessage");

    if (backBtn) {
        backBtn.addEventListener("click", () => {
            window.location.href = "index.html";
        });
    }

    if (quizCodeInput) {
        quizCodeInput.addEventListener("input", () => {
            errorMessage.textContent = "";
        });
    }

    if (joinBtn) {
        joinBtn.addEventListener("click", async () => {
            const quizCode = quizCodeInput.value.trim();
            if (!quizCode) {
                errorMessage.textContent = "Please enter quiz code.";
                return;
            }

            const result = await fetchQuiz(quizCode, true);
            console.log("join published result", { quizCode, result });

            if (result.error || !result.data) {
                if (result.error) {
                    console.warn("fetchQuiz error", result.error);
                    errorMessage.textContent = `Error contacting server: ${result.error.message}`;
                }
                // check if quiz exists but isn't published
                const result2 = await fetchQuiz(quizCode, false);
                console.log("join unpublished check", { quizCode, result2 });
                if (result2.data && !result2.error) {
                    errorMessage.textContent = "Quiz exists but is not yet published.";
                } else {
                    if (!result.error) {
                        // only show not found if there wasn't a server error
                        errorMessage.textContent = "Quiz not found.";
                    }
                }
                return;
            }

            const actualId = result.data.id;
            window.location.href = `quiz.html?quiz=${actualId}`;
        });
    }
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initJoinPage);
} else {
    initJoinPage();
}
