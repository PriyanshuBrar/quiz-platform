import { supabase } from "./supabase.js";


const { data: { session } } = await supabase.auth.getSession();
if (!session) {
  window.location.href = "login.html";
}


const tableBody = document.getElementById("leaderboardBody");

const params = new URLSearchParams(window.location.search);
const quizId = params.get("quiz");
if (!quizId) {
  tableBody.innerHTML = `<tr><td colspan="3">Invalid quiz link</td></tr>`;
  throw new Error("quizId missing");
}

async function loadLeaderboard() {
  // grab everything from the leaderboard view; the view itself
  // should already resolve the user->profile join and expose a
  // username or name column
  const { data, error } = await supabase
    .from("leaderboard_view")
    .select("*")
    .eq("quiz_id", quizId)
    // sort high scores first; ties broken by shorter total_time
    .order("score", { ascending: false })
    .order("total_time", { ascending: true });

  if (error) {
    console.error(error);
    tableBody.innerHTML = `
      <tr>
        <td colspan="3">${error.message}</td>
      </tr>
    `;
    return;
  }

  console.log("leaderboard data", data);
  tableBody.innerHTML = "";

  if (!data || data.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="3">No results yet</td></tr>`;
    return;
  }

  data.forEach((row, index) => {
    const tr = document.createElement("tr");
    // view should supply a username/name column directly
    const displayName = row.username || row.name || "(unknown)";
    tr.innerHTML = `
      <td>${index + 1}</td>
      <td>${displayName}</td>
      <td>${row.score}</td>
    `;
    tableBody.appendChild(tr);
  });
}

loadLeaderboard();
