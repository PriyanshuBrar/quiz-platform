import {
  SUPER_ADMIN_EMAIL,
  authenticateUser,
  clearSession,
  createAdminRequest,
  createUser,
  formatRole,
  getAdminRequestByEmail,
  getSession,
  initializeAppData,
  setSession
} from "./data.js";

initializeAppData();

const page = document.body.dataset.page;
const session = getSession();

if (page === "login") setupLogin();
if (page === "signup") setupSignup();

function persistRole(email, role) {
  localStorage.setItem("userRole", role);
  localStorage.setItem("userEmail", email || "");
}

function finalizeAuth(email, selectedRole, user) {
  let role = selectedRole;
  if ((email || "").toLowerCase() === SUPER_ADMIN_EMAIL) {
    role = "superadmin";
  }
  setSession({ id: user.id, name: user.name, email: user.email, role, isGuest: false });
  persistRole(email, role);
  if (role === "superadmin") {
    window.location.href = "./superadmin.html";
  } else if (role === "admin") {
    window.location.href = "./admin.html";
  } else {
    window.location.href = "./join.html";
  }
}

function getAdminAccessState(email) {
  const request = getAdminRequestByEmail(email);
  if (!request) return null;
  return request.status;
}

function setupLogin() {
  const form = document.getElementById("loginForm");
  const message = document.getElementById("authMessage");
  const guestLoginBtn = document.getElementById("guestLoginBtn");

  form?.addEventListener("submit", (event) => {
    event.preventDefault();
    const selectedRole = document.getElementById("loginRole").value;
    const email = document.getElementById("loginEmail").value.trim().toLowerCase();
    const password = document.getElementById("loginPassword").value;
    const user = authenticateUser(email, password);

    if (selectedRole === "superadmin" && email !== SUPER_ADMIN_EMAIL) {
      message.textContent = "Unauthorized";
      return;
    }

    if (!user && selectedRole !== "superadmin") {
      message.textContent = "Invalid email or password. Try one of the demo accounts.";
      return;
    }

    if (selectedRole === "superadmin") {
      const superAdminUser = user || {
        id: "super_demo",
        name: "Pravit Koul",
        email: SUPER_ADMIN_EMAIL,
        role: "superadmin"
      };
      message.textContent = "Super Admin login successful. Redirecting...";
      finalizeAuth(email, "superadmin", superAdminUser);
      return;
    }

    if (!user) {
      message.textContent = "Invalid email or password.";
      return;
    }

    if (email === SUPER_ADMIN_EMAIL) {
      message.textContent = "Super Admin login successful. Redirecting...";
      finalizeAuth(email, "superadmin", user);
      return;
    }

    if (selectedRole === "admin") {
      const status = getAdminAccessState(email) || createAdminRequest({ name: user.name, email, reason: "Requested from admin login flow." }).status;
      if (status === "approved") {
        message.textContent = "Admin login successful. Redirecting...";
        finalizeAuth(email, "admin", user);
        return;
      }
      if (status === "rejected") {
        alert("Access denied");
        message.textContent = "Access denied";
        return;
      }
      alert("Waiting for Super Admin approval");
      message.textContent = "Waiting for Super Admin approval";
      return;
    }

    message.textContent = "Login successful. Redirecting...";
    finalizeAuth(email, "user", user);
  });

  guestLoginBtn?.addEventListener("click", () => {
    setSession({ id: `guest_${Date.now()}`, name: "Guest Participant", email: "", role: "user", isGuest: true });
    persistRole("", "user");
    window.location.href = "./join.html";
  });
}

function setupSignup() {
  const roleSelect = document.getElementById("signupRole");
  const requestReasonWrap = document.getElementById("requestReasonWrap");
  const requestReason = document.getElementById("requestReason");
  const form = document.getElementById("signupForm");
  const message = document.getElementById("signupMessage");

  roleSelect?.addEventListener("change", () => {
    requestReasonWrap.classList.toggle("hidden-block", roleSelect.value !== "admin_request");
  });

  form?.addEventListener("submit", (event) => {
    event.preventDefault();
    const name = document.getElementById("signupName").value.trim();
    const email = document.getElementById("signupEmail").value.trim();
    const password = document.getElementById("signupPassword").value.trim();
    const requestedRole = roleSelect.value;

    if (!name || !email || !password) {
      message.textContent = "Please complete all required fields.";
      return;
    }
    if (requestedRole === "admin_request" && !requestReason.value.trim()) {
      message.textContent = "Please include a short reason for admin access.";
      return;
    }
    if (requestedRole === "superadmin" && email.toLowerCase() !== SUPER_ADMIN_EMAIL) {
      message.textContent = "Unauthorized";
      return;
    }

    const signupRole = email.toLowerCase() === SUPER_ADMIN_EMAIL || requestedRole === "superadmin" ? "superadmin" : "user";
    const result = createUser({ name, email, password, role: signupRole });
    if (result.error) {
      message.textContent = result.error;
      return;
    }

    if (signupRole === "superadmin") {
      message.textContent = "Super Admin signup successful. Redirecting...";
      finalizeAuth(email, "superadmin", result.user);
      return;
    }

    if (requestedRole === "admin_request") {
      createAdminRequest({ name, email, reason: requestReason.value });
      persistRole(email, "user");
      message.textContent = "Account created. Waiting for Super Admin approval.";
      alert("Waiting for Super Admin approval");
    } else {
      message.textContent = "Signup successful. Redirecting...";
      finalizeAuth(email, "user", result.user);
      return;
    }

    form.reset();
    requestReasonWrap.classList.add("hidden-block");
  });
}

window.addEventListener("pageshow", () => {
  if (!getSession()) clearSession();
});
