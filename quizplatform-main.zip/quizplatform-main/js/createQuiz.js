import { supabase } from "./supabase.js";


const { data: { session } } = await supabase.auth.getSession();
if (!session) {
  window.location.href = "login.html";
}

// helper to initialize page
function init() {
    console.log("createQuiz.js init");
    const createBtn = document.getElementById("createQuizBtn");
    const backBtn = document.getElementById("backBtn");
    const passwordInput = document.getElementById("adminPassword");
    const titleInput = document.getElementById("quizTitle");
    const message = document.getElementById("message");

    if (!createBtn || !backBtn) {
        console.error("required buttons missing", { createBtn, backBtn });
        return;
    }

    
    createBtn.addEventListener("click", async () => {

        // first verify admin password
        const password = passwordInput.value;
        const required = "Setup@1234";
        if (password !== required) {
            message.textContent = "Incorrect password";
            return;
        }

        const title = titleInput.value.trim();

        if (!title) {
            message.textContent = "Please enter quiz title";
            return;
        }

        const { data: { user } } = await supabase.auth.getUser();

        if (!user) {
            window.location.href = "login.html";
            return;
        }

        // generate a short alphanumeric code for players to use
    function generateCode(length = 6) {
        const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        let result = "";
        for (let i = 0; i < length; i++) {
            result += chars[Math.floor(Math.random() * chars.length)];
        }
        return result;
    }

    const code = generateCode();

    const { data, error } = await supabase
            .from("quizzes")
            .insert([
                {
                    title: title,
                    creator_id: user.id,
                    status: "draft",
                    code: code
                }
            ])
            .select()
            .single();

        if (error) {
            message.textContent = error.message;
            return;
        }

        // show the code briefly so creator can copy/share
        message.textContent = `Quiz created! Share code: ${data.code || data.id}`;

        // Go to add questions page, include code param for display
        window.location.href = `add-questions.html?quiz=${data.id}&code=${data.code || data.id}`;
    });


    // BACK BUTTON
    backBtn.addEventListener("click", () => {
        window.location.href = "index.html";
    });
}

// attach init either immediately or via DOMContentLoaded
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
} else {
    init();
}
