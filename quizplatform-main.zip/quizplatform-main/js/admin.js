import {
  SUPER_ADMIN_EMAIL,
  clearSession,
  createQuiz,
  findQuizById,
  formatRole,
  formatStatus,
  getAdminRequests,
  getCurrentRoom,
  getQuizzes,
  getSession,
  getUsers,
  saveAdminRequests,
  saveUsers,
  setCurrentRoom,
  updateQuiz,
  initializeAppData
} from "./data.js";

initializeAppData();

const page = document.body.dataset.page;
const session = getSession();
const storedRole = localStorage.getItem("userRole");
const storedEmail = (localStorage.getItem("userEmail") || "").toLowerCase();

const isAdminAllowed = session && (session.role === "admin" || storedRole === "admin");
const isSuperAdminAllowed =
  session &&
  (session.role === "superadmin" || storedRole === "superadmin") &&
  storedEmail === SUPER_ADMIN_EMAIL &&
  (session.email || "").toLowerCase() === SUPER_ADMIN_EMAIL;

if (!session || (page === "admin" && !isAdminAllowed) || (page === "superadmin" && !isSuperAdminAllowed)) {
  window.location.href = "./login.html";
}

if (page === "admin") setupAdminPage();
if (page === "superadmin") setupSuperAdminPage();

function setupAdminPage() {
  document.getElementById("adminIdentity").textContent = `${session.name} - ${formatRole(session.role)}`;
  setupTabs();
  setupQuizCreation();
  renderManageList();
  renderHostList();
  bindLogout();
}

function setupTabs() {
  const tabs = document.querySelectorAll(".tab-link");
  const sections = document.querySelectorAll(".dashboard-tab");

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((item) => item.classList.remove("active"));
      sections.forEach((item) => item.classList.remove("active"));
      tab.classList.add("active");
      document.getElementById(tab.dataset.tabTarget).classList.add("active");
    });
  });
}

function setupQuizCreation() {
  const questionBuilder = document.getElementById("questionBuilder");
  const addQuestionBtn = document.getElementById("addQuestionBtn");
  const quizForm = document.getElementById("quizForm");
  const message = document.getElementById("quizFormMessage");

  if (!questionBuilder.children.length) addQuestionCard();

  addQuestionBtn.addEventListener("click", () => addQuestionCard());

  quizForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const title = document.getElementById("quizTitle").value.trim();
    const description = document.getElementById("quizDescription").value.trim();
    const questionCards = [...document.querySelectorAll(".question-card")];
    const questions = [];

    for (const card of questionCards) {
      const type = card.querySelector(".question-type").value;
      const prompt = card.querySelector(".question-prompt").value.trim();
      const timer = Number(card.querySelector(".question-timer").value) || 20;
      const image = card.querySelector(".question-image").value.trim();

      if (!prompt) {
        message.textContent = "Each question needs a prompt.";
        return;
      }

      if (type === "subjective") {
        const correctAnswer = card.querySelector(".question-answer").value.trim();
        if (!correctAnswer) {
          message.textContent = "Subjective questions need a reference answer.";
          return;
        }
        questions.push({ type, prompt, timer, correctAnswer, image: "" });
        continue;
      }

      const options = [...card.querySelectorAll(".question-option")].map((input) => input.value.trim());
      const correctAnswer = card.querySelector(".question-correct").value.trim();
      if (options.some((option) => !option) || !correctAnswer) {
        message.textContent = "MCQ and image questions need all options and a correct answer.";
        return;
      }

      questions.push({ type, prompt, timer, image: type === "image" ? image : "", options, correctAnswer });
    }

    const quiz = createQuiz({ title, description, questions, createdBy: session.id });
    message.textContent = `Saved "${quiz.title}" with ${quiz.questions.length} questions.`;
    quizForm.reset();
    questionBuilder.innerHTML = "";
    addQuestionCard();
    renderManageList();
    renderHostList();
  });
}

function addQuestionCard() {
  const questionBuilder = document.getElementById("questionBuilder");
  const card = document.createElement("article");
  card.className = "question-card";
  card.innerHTML = `
    <div class="question-card-header">
      <h3>Question ${questionBuilder.children.length + 1}</h3>
      <button class="button danger remove-question-btn" type="button">Remove</button>
    </div>
    <div class="grid-two">
      <label>
        <span>Question type</span>
        <select class="question-type">
          <option value="mcq">MCQ</option>
          <option value="subjective">Subjective</option>
          <option value="image">Image-based</option>
        </select>
      </label>
      <label>
        <span>Timer (seconds)</span>
        <input class="question-timer" type="number" min="10" max="120" value="20">
      </label>
    </div>
    <label>
      <span>Prompt</span>
      <textarea class="question-prompt" rows="3" placeholder="Write your question"></textarea>
    </label>
    <div class="mcq-fields">
      <div class="option-grid">
        <label><span>Option A</span><input class="question-option" type="text" placeholder="Option A"></label>
        <label><span>Option B</span><input class="question-option" type="text" placeholder="Option B"></label>
        <label><span>Option C</span><input class="question-option" type="text" placeholder="Option C"></label>
        <label><span>Option D</span><input class="question-option" type="text" placeholder="Option D"></label>
      </div>
      <label>
        <span>Correct option value</span>
        <input class="question-correct" type="text" placeholder="Exactly match the correct option text">
      </label>
    </div>
    <div class="subjective-fields hidden-block">
      <label>
        <span>Expected answer</span>
        <textarea class="question-answer" rows="2" placeholder="Reference answer for scoring"></textarea>
      </label>
    </div>
    <div class="image-fields hidden-block">
      <label>
        <span>Image URL</span>
        <input class="question-image" type="text" placeholder="https://example.com/image.jpg">
      </label>
    </div>
    <p class="question-meta">Each question is automatically worth 10 points.</p>
  `;

  questionBuilder.appendChild(card);
  syncQuestionTitles();

  card.querySelector(".remove-question-btn").addEventListener("click", () => {
    if (questionBuilder.children.length === 1) return;
    card.remove();
    syncQuestionTitles();
  });

  card.querySelector(".question-type").addEventListener("change", (event) => {
    const type = event.target.value;
    card.querySelector(".mcq-fields").classList.toggle("hidden-block", type === "subjective");
    card.querySelector(".subjective-fields").classList.toggle("hidden-block", type !== "subjective");
    card.querySelector(".image-fields").classList.toggle("hidden-block", type !== "image");
  });
}

function syncQuestionTitles() {
  document.querySelectorAll(".question-card").forEach((card, index) => {
    card.querySelector("h3").textContent = `Question ${index + 1}`;
  });
}

function renderManageList() {
  const target = document.getElementById("quizManageList");
  const quizzes = getQuizzes().filter((quiz) => quiz.createdBy === session.id);

  if (!quizzes.length) {
    target.innerHTML = `<article class="quiz-card"><p>No quizzes created yet. Start by creating one in the first tab.</p></article>`;
    return;
  }

  target.innerHTML = quizzes.map((quiz) => `
    <article class="quiz-card">
      <div class="meta-row">
        <h3>${quiz.title}</h3>
        <span class="badge neutral">${formatStatus(quiz.host.status)}</span>
      </div>
      <p>${quiz.description}</p>
      <div class="meta-row">
        <span>${quiz.questions.length} questions</span>
        <span>Room: ${quiz.host.roomCode}</span>
      </div>
      <div class="card-actions">
        <button class="button secondary regenerate-code-btn" data-quiz-id="${quiz.id}" type="button">Regenerate Room Code</button>
        <button class="button ghost reset-quiz-btn" data-quiz-id="${quiz.id}" type="button">Reset Attempts</button>
      </div>
    </article>
  `).join("");

  target.querySelectorAll(".regenerate-code-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const quiz = findQuizById(button.dataset.quizId);
      updateQuiz(quiz.id, {
        ...quiz,
        host: { ...quiz.host, roomCode: String(Math.floor(100000 + Math.random() * 900000)), status: "draft", startedAt: null, endedAt: null },
        participants: [],
        attempts: []
      });
      renderManageList();
      renderHostList();
    });
  });

  target.querySelectorAll(".reset-quiz-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const quiz = findQuizById(button.dataset.quizId);
      updateQuiz(quiz.id, {
        ...quiz,
        participants: [],
        attempts: [],
        host: { ...quiz.host, status: "draft", resultsVisible: false, startedAt: null, endedAt: null }
      });
      renderManageList();
      renderHostList();
    });
  });
}

function renderHostList() {
  const target = document.getElementById("hostQuizList");
  const quizzes = getQuizzes().filter((quiz) => quiz.createdBy === session.id);

  if (!quizzes.length) {
    target.innerHTML = `<article class="quiz-card"><p>Create a quiz first to start hosting.</p></article>`;
    return;
  }

  target.innerHTML = quizzes.map((quiz) => `
    <article class="quiz-card">
      <div class="meta-row">
        <h3>${quiz.title}</h3>
        <span class="badge ${quiz.host.status === "live" ? "" : "neutral"}">${formatStatus(quiz.host.status)}</span>
      </div>
      <p>${quiz.description}</p>
      <div class="meta-row">
        <span>Room code: <strong>${quiz.host.roomCode}</strong></span>
        <span>${quiz.participants.length} joined</span>
      </div>
      <div class="meta-row">
        <span>${quiz.attempts.length} attempts submitted</span>
        <span>Results: ${quiz.host.resultsVisible ? "Visible" : "Hidden"}</span>
      </div>
      <div class="card-actions">
        <button class="button primary host-start-btn" data-quiz-id="${quiz.id}" type="button">${quiz.host.status === "live" ? "Restart Quiz" : "Start Quiz"}</button>
        <button class="button secondary host-end-btn" data-quiz-id="${quiz.id}" type="button">End Quiz</button>
        <button class="button ghost toggle-result-btn" data-quiz-id="${quiz.id}" type="button">${quiz.host.resultsVisible ? "Hide Results" : "Show Results"}</button>
      </div>
    </article>
  `).join("");

  target.querySelectorAll(".host-start-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const quiz = findQuizById(button.dataset.quizId);
      updateQuiz(quiz.id, { ...quiz, host: { ...quiz.host, status: "live", startedAt: new Date().toISOString(), endedAt: null, resultsVisible: false }, attempts: [] });
      setCurrentRoom({ quizId: quiz.id, roomCode: quiz.host.roomCode });
      renderManageList();
      renderHostList();
    });
  });

  target.querySelectorAll(".host-end-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const quiz = findQuizById(button.dataset.quizId);
      updateQuiz(quiz.id, { ...quiz, host: { ...quiz.host, status: "ended", endedAt: new Date().toISOString() } });
      const currentRoom = getCurrentRoom();
      if (currentRoom?.quizId === quiz.id) setCurrentRoom({ ...currentRoom, ended: true });
      renderManageList();
      renderHostList();
    });
  });

  target.querySelectorAll(".toggle-result-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const quiz = findQuizById(button.dataset.quizId);
      updateQuiz(quiz.id, { ...quiz, host: { ...quiz.host, resultsVisible: !quiz.host.resultsVisible } });
      renderManageList();
      renderHostList();
    });
  });
}

function setupSuperAdminPage() {
  document.getElementById("superAdminIdentity").textContent = `${session.name} - ${formatRole(session.role)}`;
  renderAdminRequests();
  bindLogout();
}

function renderAdminRequests() {
  const requestList = document.getElementById("adminRequestList");
  const stats = document.getElementById("requestStats");
  const requests = getAdminRequests();
  const pending = requests.filter((request) => request.status === "pending").length;
  const approved = requests.filter((request) => request.status === "approved").length;
  const rejected = requests.filter((request) => request.status === "rejected").length;

  stats.innerHTML = `
    <article class="stat-card panel"><strong>${pending}</strong><span>Pending requests</span></article>
    <article class="stat-card panel"><strong>${approved}</strong><span>Approved</span></article>
    <article class="stat-card panel"><strong>${rejected}</strong><span>Rejected</span></article>
  `;

  requestList.innerHTML = requests.map((request) => `
    <article class="request-card">
      <div class="meta-row">
        <h3>${request.name}</h3>
        <span class="badge ${request.status === "pending" ? "warning" : "neutral"}">${formatStatus(request.status)}</span>
      </div>
      <p>${request.email}</p>
      <p>${request.reason}</p>
      <div class="card-actions">
        <button class="button primary review-request-btn" data-request-id="${request.id}" data-status="approved" type="button">Approve</button>
        <button class="button danger review-request-btn" data-request-id="${request.id}" data-status="rejected" type="button">Reject</button>
      </div>
    </article>
  `).join("");

  requestList.querySelectorAll(".review-request-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const requestsData = getAdminRequests();
      const request = requestsData.find((entry) => entry.id === button.dataset.requestId);
      request.status = button.dataset.status;
      saveAdminRequests(requestsData);
      if (button.dataset.status === "approved") {
        const users = getUsers();
        const matchedUser = users.find((user) => user.email === request.email);
        if (matchedUser) {
          matchedUser.role = "admin";
          saveUsers(users);
        }
      }
      renderAdminRequests();
    });
  });
}

function bindLogout() {
  document.getElementById("logoutBtn")?.addEventListener("click", () => {
    clearSession();
    window.location.href = "./login.html";
  });
}
